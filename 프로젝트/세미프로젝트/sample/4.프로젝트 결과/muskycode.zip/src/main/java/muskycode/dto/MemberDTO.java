package muskycode.dto;

public class MemberDTO {
	private String MID;
	private String MPW;
	private String MNAME;
	private String MADDRESS1;
	private String MADDRESS2;
	private String MZIP;
	private String MPHONE;
	private String MEMAIL;
	private int MRESERVES;
	private int MGRADE;

	public MemberDTO() {
		// TODO Auto-generated constructor stub
	}

	public String getMID() {
		return MID;
	}

	public void setMID(String mID) {
		MID = mID;
	}

	public String getMPW() {
		return MPW;
	}

	public void setMPW(String mPW) {
		MPW = mPW;
	}

	public String getMNAME() {
		return MNAME;
	}

	public void setMNAME(String mNAME) {
		MNAME = mNAME;
	}

	public String getMADDRESS1() {
		return MADDRESS1;
	}

	public void setMADDRESS1(String mADDRESS1) {
		MADDRESS1 = mADDRESS1;
	}

	public String getMADDRESS2() {
		return MADDRESS2;
	}

	public void setMADDRESS2(String mADDRESS2) {
		MADDRESS2 = mADDRESS2;
	}

	public String getMZIP() {
		return MZIP;
	}

	public void setMZIP(String mZIP) {
		MZIP = mZIP;
	}

	public String getMPHONE() {
		return MPHONE;
	}

	public void setMPHONE(String mPHONE) {
		MPHONE = mPHONE;
	}

	public String getMEMAIL() {
		return MEMAIL;
	}

	public void setMEMAIL(String mEMAIL) {
		MEMAIL = mEMAIL;
	}

	public int getMRESERVES() {
		return MRESERVES;
	}

	public void setMRESERVES(int mRESERVES) {
		MRESERVES = mRESERVES;
	}

	public int getMGRADE() {
		return MGRADE;
	}

	public void setMGRADE(int mGRADE) {
		MGRADE = mGRADE;
	}

}
